<!-- Favicon -->
<link rel="icon" type="image/png" href="./assets/images/logo-icon.png">

<!-- Bootstrap -->
<link rel="stylesheet" href="./assets/lib/bootstrap/css/bootstrap.css">

<!-- Fontawesome -->
<link rel="stylesheet" href="./assets/lib/fontawesome/css/all.css">

<!-- Scroll -->
<script type="text/javascript" src="./assets/lib/scroll/modernizr.js"></script>
<link rel="stylesheet" src="./assets/lib/scroll/style.css">

<!-- Root -->
<link rel="stylesheet" href="./assets/css/master.css">