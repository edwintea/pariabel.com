<!-- Footer -->
<footer class="bg-black">
	<div class="container">
		<div class="box-copyright link">
			<i class="far fa-copyright"></i> 2020 Pariabel.com
			<a href="#section1">
				<div class="box-top">
					<img src="./assets/images/icon-arrow-up.png">
				</div>
			</a>
		</div>
	</div>
</footer>