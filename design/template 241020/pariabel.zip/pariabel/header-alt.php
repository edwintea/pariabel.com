<!-- Header -->
<header>
	<div class="nav-header">
		<div class="container">
			<div class="box-header-alt">
				<div class="left-header-alt">
					<div class="box-table">
						<div class="display-table">
							<div class="display-table-cell">
								<div class="box-lang">
									<div class="list-lang">
										<a href="#" class="active-lang">EN</a>
									</div>
									<div class="list-lang">
										<a href="#">ID</a>
									</div>
									<div class="clearer"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="center-header-alt">
					<div class="box-table">
						<div class="display-table">
							<div class="display-table-cell">
								<a href="products.php">
									<div class="box-logo">
										<img src="./assets/images/img-logo.png">
									</div>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="right-header-alt">
					<div class="box-table">
						<div class="display-table">
							<div class="display-table-cell">
								
								<!-- Sebelum Login -->
								<div class="box-login actDemo" id="btn-js-login">
									<i class="far fa-user"></i> <span>Login</span>
								</div>

							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</header>