<!-- Header -->
<header>
	<div class="nav-header">
		<div class="container">
			<div class="box-header-alt">
				<div class="left-header-alt">
					<div class="box-table">
						<div class="display-table">
							<div class="display-table-cell">
								<div class="box-lang">
									<div class="list-lang">
										<a href="#" class="active-lang">EN</a>
									</div>
									<div class="list-lang">
										<a href="#">ID</a>
									</div>
									<div class="clearer"></div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="center-header-alt">
					<div class="box-table">
						<div class="display-table">
							<div class="display-table-cell">
								<a href="products-member.php">
									<div class="box-logo">
										<img src="./assets/images/img-logo.png">
									</div>
								</a>
							</div>
						</div>
					</div>
				</div>
				<div class="right-header-alt">
					<div class="box-table">
						<div class="display-table">
							<div class="display-table-cell">
								

								<!-- Sesudah Login -->
								<div class="box-account">
									<div class="box-table">
										<div class="display-table">
											<div class="display-table-cell">
												<div class="box-content-account">
													
													<!-- Jika belum update foto profil -->
													<div class="left-content-account">
														A
													</div>

													<!-- Jika sudah update foto profil
													<div class="left-content-account-alt" style="background-image: url('./assets/images/img-andri.png');">
													</div>
													 -->
													
													<div class="center-content-account">
														<span>Halo</span>
														<div class="title-content-account">Andriana</div>
													</div>
													<div class="right-content-account">
														<i class="fas fa-chevron-down"></i>
													</div>
												</div>
											</div>
										</div>
									</div>
									<div class="box-dropdown">
										<div class="menu-dropdown">
											<a href="products-member.php">
												<span>Home</span>
											</a>
											<a href="my-account.php">
												<span>My Account</span>
											</a>
											<span class="actLogout">
												Logout
											</span>
										</div>
									</div>
								</div>
								

							</div>
						</div>
					</div>
				</div>

			</div>
		</div>
	</div>
</header>