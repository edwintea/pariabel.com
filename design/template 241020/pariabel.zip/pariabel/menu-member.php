<div class="box-avatar">

	<div class="img-avatar">
	A
	</div>
	<!--
	<div class="img-avatar-alt" style="background-image: url('./assets/images/img-andri.png');"></div>
	-->
	<div class="title-avatar">
		Andriana
	</div>
	<span>
		Join Date : 20 Jul 2020
	</span>
	<div class="clearer"></div>
	
</div>
<div class="line-menu-member"></div>
<div class="box-menu-member">
	<div class="list-menu-member">
		<a href="products-member.php">
			<i class="fas fa-home"></i> <small>Home</small>
			<div class="clearer"></div>
		</a>
	</div>
	<div class="list-menu-member active-menu-member">
		<a href="my-account.php">
			<i class="fas fa-user"></i> <small>My Account</small>
			<div class="clearer"></div>
		</a>
	</div>
	<div class="line-menu-member"></div>
	<div class="list-menu-member actLogout">
		<i class="fas fa-sign-out-alt"></i> <small>Logout</small>
		<div class="clearer"></div>
	</div>
</div>