<!-- Footer -->
<footer class="bg-black">
	<div class="container">
		<div class="box-footer">
			<i class="far fa-copyright"></i> 2020 Pariabel.com
			<div class="back-top link">
				<a href="#section1">
					<i class="fas fa-chevron-up"></i>
				</a>
			</div>
		</div>
	</div>
</footer>