<!-- Jquery -->
<script type="text/javascript" src="./assets/js/jquery.min.js"></script>
<script type="text/javascript" src="./assets/lib/scroll/modernizr.js"></script>
<script type="text/javascript" src="./assets/lib/scroll/main.js"></script>
<script type="text/javascript" src="./assets/lib/parallax/parallax.js"></script>
<script type="text/javascript" src="./assets/js/master.js"></script>